import csv
with open("./templates/html/data/pdf_data.csv", "a+") as pdf_dat:
    pdf_dats= csv.reader(pdf_dat)
    for i in pdf_dats:
        print(i)