from flask import Flask,render_template,request,url_for
from pandas import read_csv


pdf_dat= read_csv("./templates/html/data/pdf_data.csv")

app = Flask(__name__)
search=""

@app.route("/",methods=["GET","POST"])


def front_page():
   

    while True:

        if request.method=="POST" :
             search= request.form["search"]
             print(search)
        
        pdf_name=pdf_dat["name"]
        pdf_address=pdf_dat["address"]
        pdf_subject=pdf_dat["subject"]
        return render_template("/index.html",pdf_name=pdf_name,pdf_address=pdf_address, search=search)
    
    


    
        
                
if __name__=="__main__":
    
    app.run(debug=False)